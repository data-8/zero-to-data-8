OK_FORMAT = True

test = {   'name': 'q2_3',
    'points': [0, 0, 0, 9],
    'suites': [   {   'cases': [   {'code': '>>> 1 <= cutoff_five_percent <= 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> cutoff_five_percent == 3\nFalse', 'hidden': False, 'locked': False},
                                   {'code': '>>> cutoff_five_percent == 2\nFalse', 'hidden': False, 'locked': False},
                                   {'code': '>>> cutoff_five_percent == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
