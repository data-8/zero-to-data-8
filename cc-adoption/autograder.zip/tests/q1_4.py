OK_FORMAT = True

test = {   'name': 'q1_4',
    'points': [0, 9],
    'suites': [   {   'cases': [   {'code': '>>> type(one_resampled_difference(votes)) in set([float, np.float64]) \nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> -6 <= float(one_resampled_difference(votes)) <= 15\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
