OK_FORMAT = True

test = {   'name': 'q1_6',
    'points': [0, 2, 7],
    'suites': [   {   'cases': [   {'code': '>>> -5 <= diff_lower_bound <= diff_upper_bound <= 20\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> -1.8 <= diff_lower_bound <= diff_upper_bound <= 13.4\nTrue', 'hidden': True, 'locked': False},
                                   {   'code': '>>> all([diff_lower_bound == percentile(2.5, sampled_leads), diff_upper_bound == percentile(97.5, sampled_leads)])\nTrue',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
